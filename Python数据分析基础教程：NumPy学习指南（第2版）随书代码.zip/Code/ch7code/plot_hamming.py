import numpy as np
from pylab import *

window = np.hamming(42)
plot(window)
show()

