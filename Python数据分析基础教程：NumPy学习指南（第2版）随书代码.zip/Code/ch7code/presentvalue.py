import numpy as np

print "Present value", np.pv(0.03/4, 5 * 4, -10, 1376.09633204)
