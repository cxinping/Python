import numpy as np

print "Internal rate of return", np.irr([-100, 38, 48, 90, 17, 36])
