import numpy as np
from pylab import *

window = np.kaiser(42, 0)
plot(window)
show()
