import numpy as np
from pylab import *

x = np.linspace(0, 4, 100)
vals = np.i0(x)

plot(x, vals)
show()
