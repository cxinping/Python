package com.bank.SpringBootPro1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPro1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPro1Application.class, args);
	}
}
